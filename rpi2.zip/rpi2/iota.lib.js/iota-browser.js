
window.IOTA = require('./lib/iota.js');
