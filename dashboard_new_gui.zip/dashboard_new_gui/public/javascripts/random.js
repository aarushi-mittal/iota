rpi1 -> rpi_2
//trigger on tx id 
//publish to rpi_2
time_period
//click
//pick it & send via tangle
//